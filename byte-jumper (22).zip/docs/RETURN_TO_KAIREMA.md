# Как вернуть игру в Kairema

Игра лежит в `app/src/main/assets/features/game/` с тем же путём и именами, что и в Kairema (`app/src/main/assets/ui/features/game/`). Заглушка `shim/` в Kairema не нужна: все её функции там уже есть.

## Шаги

1. Возьми свежий Kairema (актуальный `main`, смотри версию в `app/build.gradle.kts`: приложение мог менять другой Клауд).
2. Замени три файла в `app/src/main/assets/ui/features/game/` файлами из этой игры: `engine.js`, `game.js`, `game.css` и (с версии 0.2.0) новые `core.js`, `story.js`, `arena.js`, `fx.js`, `storyui.js`. В `index.html` Kairema порядок: core, engine, story, fx, game, storyui.
3. Если игра изменилась больше, чем эти три файла (появились новые файлы, например `levels.js` или картинки), добавь их в ту же папку и в `index.html` Kairema (скрипты после `core/*.js`, как сейчас идут `engine.js` и `game.js`; стиль `game.css` рядом с остальными).
4. Если в игре появились вызовы функций, которых нет в Kairema, а в `shim/shim.js` они есть, перенеси такие функции в ядро Kairema или перепиши вызов. Список функций, которые игра берёт у ядра: `$`, `el`, `ic`, `L`, `i18nAdd`, `Hooks`, `SCREENS`, `toast`, `page`, `esc`.
5. Прогони в Kairema тест игры `docs/tests/game047.test.py` (и общий набор), подними версию в трёх местах, обнови CHANGELOG, NOTES, MAP. Отдай архив Kairema **полным**.

## Что не потеряется

- Ключ сохранения `kairema.game.v1` не меняется: прогресс игрока в Kairema останется как был.
- Строка «Байт-прыгун» в Настройках и плашка «Нет сети — поиграть?» уже есть в `game.js` и `setlayout.js` Kairema, ничего добавлять не надо.

## Важно

Пока игра живёт отдельно, в Kairema её не правят (иначе придётся сливать файлы вручную). Источник правды один: этот репозиторий. Если срочно нужно исправить игру в Kairema, исправь её и здесь тоже.

## Дополнение (0.6.1): Искра

Новые файлы: `spark.js` и папка `spark/` (картинка `spark.png`, путь `features/game/spark/spark.png` относительный, папку копировать целиком). В `index.html` Kairema `spark.js` подключается после `fx.js` и до `game.js`.

## Дополнение (0.7.0): новый дизайн

Новый файл `art.js` подключается после `spark.js` и до `game.js`. Стили нового дизайна добавлены в конец `game.css` и действуют только внутри `.gm` (локальные цвета), на остальное приложение не влияют.


## Дополнение (0.7.1): строгая палитра

Новый файл `bossart.js` подключается после `art.js` и до `game.js` (порядок: shim, core, engine, story, arena, fx, spark, art, bossart, game, storyui). `art.js` переписан: те же имена функций плюс `arenaHud`, `joy`, `jump`, `rejectBtn`; у `plat` появился 5-й параметр состояния. `spark.js` получил `icon()`, картинка `spark/spark.png` обесцвечена. Блок стилей в конце `game.css` заменён (по-прежнему только внутри `.gm`). Цвета лаунчера: глаза значка стали белыми.


## Дополнение (0.7.2): Искра

`spark/spark.png` пересобран (37 кадров), `spark.js` выбирает кадры по состоянию. Скрипт `docs/tools/make_spark_atlas.py` и `spark_base.png` нужны только для пересборки атласа, в игру не входят. Из `game.js` убраны наклоны героя по скорости.


## С версии 0.8.0

Новые файлы в той же папке: `levels.js` (после `engine.js`) и `levelview.js` (после `bossart.js`, до `game.js`). Порядок скриптов: shim, core, engine, levels, story, arena, fx, spark, art, bossart, levelview, game, storyui. В сохранении `kairema.game.v1` появилось поле `lfs` (номера уровней с найденным Потеряшкой).
