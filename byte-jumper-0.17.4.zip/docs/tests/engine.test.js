/* Тест логики без браузера: node docs/tests/engine.test.js */
const fs=require('fs'),path=require('path');const D=path.join(__dirname,'../../app/src/main/assets/features/game/');
const ld=(f,n)=>new Function((f==='art.js'?fs.readFileSync(D+'skins.js','utf8')+';':'')+fs.readFileSync(D+f,'utf8')+';return '+n)();
const GE=ld('engine.js','GameEngine'),AR=new Function(fs.readFileSync(D+'engine.js','utf8')+';'+fs.readFileSync(D+'arena.js','utf8')+';'+fs.readFileSync(D+'boss12.js','utf8')+';'+fs.readFileSync(D+'boss12view.js','utf8')+';return GameArena')(),FX=ld('fx.js','GameFX'),ST=ld('story.js','GameStory'),CO=ld('core.js','GameCore');
let ok=0,bad=[];const c=(n,v)=>{v?(ok++,console.log('ok  ',n)):(bad.push(n),console.log('FAIL',n))};
function jump(hold){const S=GE.create({mode:'level',L:1,seed:1,W:360,H:600});S.items=[];let mn=1e9;const y0=S.p.y;GE.step(S,.016,{pressed:true,down:true});mn=Math.min(mn,S.p.y);for(let i=0;i<120;i++){GE.step(S,.016,{down:hold});mn=Math.min(mn,S.p.y)}return y0-mn}
const tap=jump(false),hold=jump(true);
c('малый прыжок 55–80 px ('+Math.round(tap)+')',tap>55&&tap<80);c('большой прыжок 110–135 px ('+Math.round(hold)+')',hold>110&&hold<135);
function play(L,seed){const S=GE.create({mode:'level',L,seed,W:360,H:600});let f=0;while(!S.over&&f<60000){f++;const pw=S.x+GE.PX;let pr=false;
 for(const it of S.items)if(it.t==='bug'){const d=it.x-pw;if(d>0&&d<S.speed*.25+8&&d>S.speed*.25-26)pr=true}
 for(const q of S.pits){const d=q.a-pw;if(d>0&&d<S.speed*.17+8&&d>S.speed*.17-26)pr=true}
 GE.step(S,.016,{pressed:pr,down:pr})}return S}
c('на уровень 5 сердец',GE.create({mode:'level',L:1,seed:1,W:360,H:600}).hearts===5);
for(const L of [1,3,5,8,10]){const S=play(L,7);c('бот проходит уровень '+L+' ('+S.over+', потеряно '+S.lost+')',S.over==='win')}
{const S=GE.create({mode:'level',L:1,seed:1,W:360,H:600});S.pits.push({a:S.x+GE.PX+50,b:S.x+GE.PX+160});S.items=[];let f=0;while(!S.over&&S.lost===0&&f<600){GE.step(S,.016,{});f++}
 c('яма: минус сердце и возврат на землю, не смерть',S.lost===1&&!S.over&&S.hearts===4&&S.p.on===false||S.lost===1&&!S.over&&S.hearts===4)}
{const S=GE.create({mode:'level',L:1,seed:1,W:360,H:600});S.hearts=1;S.items=[{t:'bug',x:S.x+GE.PX,h:0}];GE.step(S,.016,{});c('последнее сердце: уровень провален',S.over==='dead')}
{const S=GE.create({mode:'level',L:2,seed:3,W:360,H:600});c('дверь в конце уровня',S.items.some(i=>i.t==='door'&&i.x===S.target+GE.PX))}
c('100 уровней, 10 актов',ST.LEVELS===100&&ST.act(100)===10&&ST.act(1)===1&&ST.act(11)===2);
c('10 глав по 9 уровней + босс, 10 боссов с текстом',ST.chapters.length===10&&ST.chapters.every(x=>x.levels.length===9)&&ST.bosses.length===10&&ST.bosses.every(b=>b.text.length>100));c('имена боссов из истории автора',ST.bosses[0].name==='Потерянный Страж'&&ST.bosses[9].name==='Кернел'&&ST.stages.length===10);
let calls=0;const ctx=new Proxy({},{get:(t,k)=>k==='save'||k==='restore'?()=>{}:k==='fillText'||k==='fillRect'?()=>{calls++}:undefined,set:()=>true});
FX.draw(ctx,360,600,1.3,0,'#fff',1);const c0=calls;FX.draw(ctx,360,600,1.3,10,'#fff',1);
c('помех нет без боссов, много на 10',c0===0&&calls>20);c('помех при 1 боссе мало',(()=>{calls=0;FX.draw(ctx,360,600,1.3,1,'#fff',1);return calls>0&&calls<8})());
for(let i=0;i<50;i++)CO.tick(40);c('ядро снижает качество при тормозах',CO.perf.q<1);

/* ---- арена босса ---- */
{const S=AR.create({W:360,H:520,seed:3});let warn=0,gone=0,seenPh={},tel=0;S.hearts=999;
 for(let f=0;f<60*200&&!S.over;f++){const k=S.key;if(k&&S.t>1){S.p.x=k.x;S.p.y=k.y-GE.PH/2}
  AR.step(S,1/60,{ax:0});seenPh[S.boss.phase]=1;tel+=S.tel.length?1:0;S.pl.forEach(q=>{if(q.st==='warn')warn++;if(q.st==='gone')gone++});S.ev.length=0}
 c('арена: босса можно победить 9 ключами ('+S.over+', t='+Math.round(S.t)+')',S.over==='win'&&S.bytes===9);
 c('арена: три фазы',seenPh[1]&&seenPh[2]&&seenPh[3]);
 c('арена: у падающей платформы есть метка до падения',warn>0&&gone>0);
 c('арена: у атак есть предупреждение (tel)',tel>0)}
{const S=AR.create({W:360,H:520,seed:3});S.p.inv=0;S.sh.push({x:S.p.x,y:S.p.y,vx:0,vy:0,r:10,kind:1});AR.step(S,.016,{ax:0});c('арена: попадание = минус сердце',S.hearts===2)}
{const S=AR.create({W:360,H:520,seed:3});S.p.x=S.W*.5;S.p.y=S.gy;S.p.on=false;for(let i=0;i<300;i++)AR.step(S,.016,{ax:0});c('арена: падение в щель без урона, возврат на платформу',S.p.y<S.H&&S.hearts===3&&S.ev.includes('fall'))}
{const S=AR.create({W:360,H:520,seed:5});S.hearts=999;let top=0;for(let f=0;f<60*30;f++){AR.step(S,1/60,{ax:0});if(S.key&&S.key.y<S.gy-150)top++}c('арена: ключ появляется на самой высокой платформе',top>0)}
{const S=AR.create({W:360,H:520,seed:5});S.p.on=true;S.p.y=S.gy-GE.PH;S.p.x=60;let mn=1e9;AR.step(S,.016,{ax:0,pressed:true,down:false});for(let i=0;i<60;i++){AR.step(S,.016,{ax:0});mn=Math.min(mn,S.p.y)}c('арена: тап = малый прыжок 55–80 px',S.gy-GE.PH-mn>55&&S.gy-GE.PH-mn<80)}

/* ---- 100 уровней ---- */
{let ok2=true,prev=-1;for(let c=1;c<=10;c++){const a=GE.levelD((c-1)*10+2),b=GE.levelD((c-1)*10+8);if(!(b>a))ok2=false;if(c>1&&GE.levelD((c-1)*10+8)<=GE.levelD((c-2)*10+8))ok2=false}
 c('сложность растёт от главы к главе',ok2);
 c('уровень 1 легче 99, длина 6000..15000',GE.levelD(1)<GE.levelD(99)&&GE.target(1)<=6100&&GE.target(99)<=15000&&GE.target(99)>12000);
 const P=GE.prm(GE.levelD(99));c('скорость ≤ 420, яма ≤ 0,8 дальности большого прыжка',P.vmax<=420&&P.gap<=.8*304);
 for(const L of [15,34,59,79,99]){const S=play(L,11);c('бот проходит уровень '+L+' ('+S.over+', потеряно '+S.lost+')',S.over==='win')}}

/* ---- боссы глав 3–4: победимы, атаки с предупреждением, без аварий (боссы 1–2 — в boss12.test.js) ---- */
for(const id of [3,4]){const S=AR.create({W:360,H:520,seed:id,id});let tel=0,kinds={},seenPh={};S.hearts=999;
 for(let f=0;f<60*260&&!S.over;f++){const k=id===3?S.sbytes[0]:S.key;if(k&&S.t>1){S.p.x=k.x;S.p.y=k.y-GE.PH/2}
  AR.step(S,1/60,{ax:0});seenPh[S.boss.phase]=1;S.tel.forEach(a=>{kinds[a.k]=1});tel+=S.tel.length?1:0;S.ev.length=0;if(S.sh.length>20)throw new Error('снарядов больше 20')}
 c('босс '+id+': победа ('+S.over+', t='+Math.round(S.t)+'), 3 фазы',S.over==='win'&&seenPh[1]&&seenPh[2]&&seenPh[3]);
 c('босс '+id+': свои атаки '+Object.keys(kinds).join(','),(id===2?kinds.edge&&kinds.col:id===3?kinds.fan:kinds.pkt)&&tel>0)}
{const S=AR.create({W:360,H:520,seed:1,id:4});S.hearts=999;let reps=0;for(let f=0;f<60*200;f++){AR.step(S,1/60,{ax:0});reps=Math.max(reps,S.rep||0);S.ev.length=0}c('Таймаут: до 7 повторов серии ('+reps+')',reps===7)}
{const S=AR.create({W:360,H:520,seed:1,id:3});S.hearts=999;S.boss.hp=60;let st=false;for(let f=0;f<60*30;f++){AR.step(S,1/60,{ax:0});if(S.pl.some(q=>q.stale))st=true;S.ev.length=0}c('Stale: есть устаревшие платформы',st)}

/* ---- боссы глав 5–7 (шаг 3) ---- */
function bot(id,seed,opt){opt=opt||{};const S=AR.create({W:360,H:520,seed,id});S.hearts=999;const k={},seen={ph:{},fw:0,flip:0,dark:0,sd:0,slow:0,wins:0,walls:0};let tel=0,telBefore=true;
 for(let f=0;f<60*300&&!S.over;f++){const kk=S.key;if(kk&&S.t>1&&!(S.flip>0)){S.p.x=kk.x;S.p.y=kk.y-GE.PH/2}
  if(opt.rej&&f%6===0)AR.reject(S);
  AR.step(S,1/60,{ax:0});seen.ph[S.boss.phase]=1;S.tel.forEach(a=>{k[a.k]=1});tel+=S.tel.length?1:0;S.ev.length=0;if(S.sh.length>20)throw new Error('снарядов больше 20');
  if(S.fw>0)seen.fw=1;if(S.flip>0)seen.flip=1;if(S.dark)seen.dark=1;if(S.sd)seen.sd=1;if(S.slow>0)seen.slow=1;if(S.wins.length)seen.wins=1;if(S.walls.length)seen.walls=1}
 return{S,k,seen,tel}}
{const r=bot(5,5);c('босс 5: победа, 3 фазы ('+r.S.over+', t='+Math.round(r.S.t)+')',r.S.over==='win'&&r.seen.ph[1]&&r.seen.ph[2]&&r.seen.ph[3]);
 c('босс 5: монеты (str), стены (wall) с предупреждением, «Лимит исчерпан» замедляет',r.k.str&&r.k.wall&&r.seen.walls&&r.seen.slow&&r.tel>0)}
{const S=AR.create({W:360,H:520,seed:2,id:5});S.walls.push({x:S.p.x+40,y:S.gy-56,h:56,t:9});S.wb=0;for(let i=0;i<90;i++)AR.step(S,1/60,{ax:1});const blocked=S.p.x<S.p.x+1&&S.p.x<=S.walls[0].x;
 const S2=AR.create({W:360,H:520,seed:2,id:5});S2.walls.push({x:S2.p.x+40,y:S2.gy-56,h:56,t:9});S2.wb=1;for(let i=0;i<90;i++)AR.step(S2,1/60,{ax:1});
 const S3=AR.create({W:360,H:520,seed:2,id:5});S3.walls.push({x:S3.p.x+40,y:S3.gy-56,h:56,t:9});let over=false;AR.step(S3,1/60,{ax:0,pressed:true,down:true});for(let i=0;i<140;i++){AR.step(S3,1/60,{ax:1,down:true});if(S3.p.x>S3.walls[0].x+14&&!S3.walls[0].dead)over=true}
 c('стена: без байта не пройти, с байтом рывок пробивает (−1 байт), сверху обойти можно',blocked&&S2.wb===0&&S2.p.x>S2.W*.22+40&&S3.walls.length>0)}
{const S=AR.create({W:360,H:520,seed:2,id:5});S.tok=5;S.boss.phase=1;S.atk=0;AR.step(S,1/60,{ax:0});const x0=S.p.x;for(let i=0;i<30;i++)AR.step(S,1/60,{ax:1});const dx=S.p.x-x0;c('замедление 20%: скорость 136 px/с ('+Math.round(dx*2)+')',S.slow>0&&Math.abs(dx*2-136)<8)}
{const r=bot(6,6,{rej:1});c('босс 6: победа ('+r.S.over+', t='+Math.round(r.S.t)+'), 3 фазы',r.S.over==='win'&&r.seen.ph[1]&&r.seen.ph[2]&&r.seen.ph[3]);c('босс 6: окна «Разрешить?» и лазер/снаряды с предупреждением',r.seen.wins&&r.tel>0&&r.k.big)}
{const S=AR.create({W:360,H:520,seed:3,id:6});S.fallT=99;S.wins.push({t:1.5,max:1.5,real:1,d:0});AR.reject(S);const a=S.chg===1&&S.wins.length===0;
 S.wins.push({t:.3,max:1.5,real:1,d:0});for(let i=0;i<30;i++)AR.step(S,1/60,{ax:0});const er=S.pl.some(q=>q.st!=='ok');
 const S2=AR.create({W:360,H:520,seed:3,id:6});S2.fallT=99;S2.atk=99;S2.wins.push({t:.2,max:1.5,real:0,d:0});for(let i=0;i<30;i++)AR.step(S2,1/60,{ax:0});const none=!S2.pl.some(q=>q.st!=='ok')&&S2.hearts===3&&S2.wins.length===0;
 c('«Отклонить»: настоящее окно даёт заряд; не успел = платформа гаснет с меткой; ложное окно без последствий',a&&er&&none)}
{const S=AR.create({W:360,H:520,seed:3,id:6});S.fallT=99;S.atk=99;S.wins.push({t:1,max:1.5,real:1,d:0},{t:.5,max:1.5,real:0,d:0});S.boss.hp=100;for(let i=0;i<5;i++){S.wins.push({t:1,max:1.5,real:1,d:0});AR.reject(S);AR.reject(S)}c('5 «Отклонить» подряд снимают часть HP босса',S.chg>=5&&S.boss.hp<100)}
{const S=AR.create({W:360,H:520,seed:3,id:6});S.boss.hp=20;const lims=[];for(const hp of [100,60,20]){S.boss.hp=hp;S.wins=[];S.atk=0;S.fallT=99;S.p.inv=99;AR.step(S,1/60,{ax:0});lims.push(S.wins[0]&&S.wins[0].max)}c('время ответа 1,5 / 1,2 / 0,9 с по фазам ('+lims+')',lims[0]===1.5&&lims[1]===1.2&&lims[2]===.9)}
{const r=bot(7,7);c('босс 7: победа ('+r.S.over+', t='+Math.round(r.S.t)+'), 3 фазы',r.S.over==='win'&&r.seen.ph[1]&&r.seen.ph[2]&&r.seen.ph[3]);c('босс 7: Эхо (копия), предупреждение гравитации, затем переворот, Тьма',r.seen.sd&&r.seen.fw&&r.seen.flip&&r.seen.dark&&r.tel>0)}
{const S=AR.create({W:360,H:520,seed:7,id:7});S.hearts=999;S.boss.hp=60;let fwT=-1,flT=-1,ceil=false,grav=false,t0=0;for(let f=0;f<60*40;f++){AR.step(S,1/60,{ax:0});S.ev.length=0;if(S.fw>0&&fwT<0)fwT=S.t;if(S.flip>0&&flT<0)flT=S.t;if(S.flip>0&&S.p.y===100&&S.p.on)ceil=true;if(S.flip>0&&S.p.vy<0)grav=false}
 c('гравитация: предупреждение ≥1 с до переворота, игрок встаёт на потолок',fwT>0&&flT-fwT>=.95&&ceil);
 const S2=AR.create({W:360,H:520,seed:7,id:7});S2.boss.hp=60;S2.hearts=999;S2.flip=0;S2.fw=1;let fl=false;for(let f=0;f<400;f++){AR.step(S2,1/60,{ax:0});if(S2.flip>0)fl=true;if(S2.flip>0)break}let yy=S2.p.y;for(let f=0;f<20;f++)AR.step(S2,1/60,{ax:0});c('при перевороте игрок падает вверх (y уменьшается)',fl&&S2.p.y<yy-5)}
{const S=AR.create({W:360,H:520,seed:7,id:7});S.hearts=999;S.boss.hp=20;AR.step(S,1/60,{ax:0});const sq=S.seq,ord=sq.ord.slice();c('Тьма: арена гаснет, три тёмных байта',S.dark&&sq.n.length===3&&ord.length===3);
 const hp0=S.boss.hp;S.fair=99;S.p.inv=99;for(const i of ord){const d=S.seq.n[i];S.p.x=d.x;S.p.y=d.y-GE.PH/2;S.atk=99;S.key=null;S.kt=99;for(let f=0;f<45;f++){S.p.x=d.x;S.p.y=d.y-GE.PH/2;S.p.vy=0;AR.step(S,1/60,{ax:0})}}
 c('Тьма: собрать байты в порядке = удар по Тени; ошибка порядка сбрасывает',S.boss.hp<hp0||S.over==='win');
 const S2=AR.create({W:360,H:520,seed:8,id:7});S2.hearts=999;S2.boss.hp=20;AR.step(S2,1/60,{ax:0});const o2=S2.seq.ord,wrong=o2[1];const d=S2.seq.n[wrong];S2.p.inv=99;S2.atk=99;S2.kt=99;for(let f=0;f<20;f++){S2.p.x=d.x;S2.p.y=d.y-GE.PH/2;S2.p.vy=0;AR.step(S2,1/60,{ax:0})}c('неверный байт: прогресс 0',S2.seq.got===0)}
{const S=AR.create({W:360,H:520,seed:9,id:7});S.hearts=999;S.fallT=99;S.atk=99;S.boss.hp=100;let traps=0;for(let f=0;f<60*20;f++){const k=Math.floor(f/50)%2;S.p.x=k?80:280;S.p.y=S.gy-GE.PH;AR.step(S,1/60,{ax:0});if(S.tel.some(a=>a.k==='big'))traps++}c('ИИ Тени: повторяющийся маршрут получает ловушку',traps>0)}

/* ---- боссы глав 8–10 (шаг 4) ---- */
function bot2(id,seed,o){o=o||{};const S=AR.create({W:360,H:520,seed,id,bytes:o.bytes||0});S.hearts=999;const k={},ph={};let tel=0,mem=0,fake=0,fz=0,fh=0,gh=0,cks={};
 for(let f=0;f<60*400&&!S.over;f++){const kk=S.key;if(kk&&S.t>1&&!S.p4){S.p.x=kk.x;S.p.y=kk.y-GE.PH/2}
  if(S.p4){const q=S.pl[4];S.p.x=q.x+q.w-20;S.p.y=q.y-GE.PH;S.p.vy=0;S.p.on=true}
  AR.step(S,1/60,{ax:0,frz:true});ph[S.boss.phase]=1;S.tel.forEach(a=>{k[a.k]=1});tel+=S.tel.length?1:0;if(S.sh.length>20)throw new Error('снарядов больше 20');
  if(S.mm.some(m=>m.real))mem=1;if(S.mm.some(m=>!m.real))fake=1;if(S.fz)fz=1;if(S.fh)fh=1;if(S.gh.length)gh=1;if(S.ck)cks[S.ck]=1;S.ev.length=0}
 return{S,k,ph,tel,mem,fake,fz,fh,gh,cks}}
{const r=bot2(8,8);c('босс 8: победа ('+r.S.over+', t='+Math.round(r.S.t)+'), 4 фазы',r.S.over==='win'&&r.ph[1]&&r.ph[2]&&r.ph[3]&&r.ph[4]);
 c('босс 8: паттерны прошлых боссов ('+Object.keys(r.k).join(',')+'), «Дамп»: настоящие и подделки',(r.k.big||r.k.row)&&(r.k.pkt||r.k.fan)&&r.k.str&&r.mem&&r.fake&&r.tel>0)}
{const S=AR.create({W:360,H:520,seed:8,id:8});S.hearts=999;S.fear[2]=4;S.atk=0;S.fallT=99;AR.step(S,1/60,{ax:0});const a=S.lastK;const S2=AR.create({W:360,H:520,seed:8,id:8});S2.fear[1]=4;S2.atk=0;S2.fallT=99;AR.step(S2,1/60,{ax:0});c('ИИ Летописца берёт паттерн, от которого игрок получил больше ударов ('+a+','+S2.lastK+')',a===2&&S2.lastK===1)}
{const S=AR.create({W:360,H:520,seed:8,id:8});S.boss.hp=20;S.atk=99;S.fallT=99;S.p.inv=0;S.mm.push({x:S.p.x,y:S.p.y+GE.PH/2,vx:0,real:0,dead:0});AR.step(S,1/60,{ax:0});const lost=S.hearts===2;
 const S2=AR.create({W:360,H:520,seed:8,id:8});S2.boss.hp=20;S2.atk=99;S2.fallT=99;S2.mm.push({x:S2.p.x,y:S2.p.y+GE.PH/2,vx:0,real:1,dead:0});AR.step(S2,1/60,{ax:0});c('воспоминания: подделка = минус сердце, настоящее собирается без урона',lost&&S2.hearts===3&&S2.memc===1)}
{const r=bot2(9,9);c('босс 9: победа ('+r.S.over+', t='+Math.round(r.S.t)+'), 3 фазы',r.S.over==='win'&&r.ph[1]&&r.ph[2]&&r.ph[3]);c('босс 9: серия «Замри» и фальшивый HUD, осколки с предупреждением',r.fz&&r.fh&&r.k.big&&r.tel>0)}
{const S=AR.create({W:360,H:520,seed:9,id:9});S.boss.hp=60;S.atk=99;S.fallT=99;S.fzQ=1;for(let i=0;i<60*2.6;i++)AR.step(S,1/60,{ax:0,frz:true});const ok=S.fzS===1&&S.hearts===3&&S.fzK===2;
 const S2=AR.create({W:360,H:520,seed:9,id:9});S2.boss.hp=60;S2.atk=99;S2.fallT=99;S2.fzQ=1;for(let i=0;i<60*2.6;i++)AR.step(S2,1/60,{ax:0,frz:false});
 c('«Замри»: удержал 1,5 с = успех и серия длиннее, не удержал = минус сердце ('+S.fzK+','+S2.hearts+')',ok&&S2.hearts===2&&S2.fzK===1)}
{const S=AR.create({W:360,H:520,seed:9,id:9});S.boss.hp=60;S.atk=99;S.fallT=99;S.fzQ=1;AR.step(S,1/60,{ax:0});let warn=0;for(let i=0;i<30;i++){AR.step(S,1/60,{ax:0,frz:false});if(S.fz&&S.fz.st==='warn')warn++}c('«Замри»: предупреждение 0,8 с до проверки (без удержания не штрафует)',warn>=40&&S.hearts===3||warn>=28&&S.hearts===3)}
{const S=AR.create({W:360,H:520,seed:9,id:9});S.boss.hp=60;S.atk=99;S.fallT=99;S.fzQ=1;const hp0=S.boss.hp;S.fzS=2;for(let i=0;i<60*2.6;i++)AR.step(S,1/60,{ax:0,frz:true});c('3 успешных «Замри» подряд = трещина сферы (удар по боссу)',S.boss.hp<hp0)}
{const r=bot2(10,10);c('босс 10: 4 фазы, победа только по мосту ('+r.S.over+', t='+Math.round(r.S.t)+')',r.S.over==='win'&&r.ph[1]&&r.ph[2]&&r.ph[3]&&r.ph[4]);c('босс 10: призраки, окна, паттерны Ядра ('+Object.keys(r.cks).join('')+')',r.gh&&Object.keys(r.cks).length>=2&&r.tel>0)}
{const S=AR.create({W:360,H:520,seed:10,id:10});S.hearts=999;S.atk=99;S.fallT=99;const p=S.p,g={x:p.x,y:S.gy-14,vx:0,dead:0};S.gh.push(g);p.y=g.y-14-GE.PH-2;p.vy=200;p.on=false;AR.step(S,1/60,{ax:0});const st=g.dead===1&&S.rem===1&&S.hearts===999;
 const S2=AR.create({W:360,H:520,seed:10,id:10});S2.atk=99;S2.fallT=99;S2.p.inv=0;S2.gh.push({x:S2.p.x,y:S2.gy-14,vx:0,dead:0});AR.step(S2,1/60,{ax:0});c('призрак: приземлиться сверху = вспомнил имя (без урона), коснуться сбоку = минус сердце',st&&S2.hearts===2)}
{const S=AR.create({W:360,H:520,seed:10,id:10});S.hearts=999;S.boss.hp=40;S.fallT=99;const ck={};for(let f=0;f<60*76;f++){AR.step(S,1/60,{ax:0});ck[S.ck]=1;S.ev.length=0;if(S.sh.length>20)throw new Error('больше 20')}c('Ядро: паттерны всех 9 боссов по 8 с ('+Object.keys(ck).join('')+')',[1,2,3,4,5,6,7,8,9].every(i=>ck[i]))}
{const mk=b=>{const S=AR.create({W:360,H:520,seed:10,id:10,bytes:b});S.hearts=999;S.boss.hp=20;for(let i=0;i<120;i++)AR.step(S,1/60,{ax:0});return S};const a=mk(0),b=mk(300);
 let quiet=true;const S=mk(0);for(let i=0;i<600;i++){AR.step(S,1/60,{ax:0});if(S.tel.length||S.sh.length)quiet=false}
 c('«Ноль»: атак нет, мост шире, чем больше байтов собрано ('+Math.round(a.pl[4].w)+'→'+Math.round(b.pl[4].w)+')',a.p4&&quiet&&b.pl[4].w>a.pl[4].w+60)}

/* ---- Искра: атлас кадров и неизменный хитбокс (0.6.1) ---- */
{const SP=ld('spark.js','GameSpark'),need=['idle','front','r0','r1','r2','r3','r4','r5','r6','r7','e0','e1','e2','e3','m0','m1','m2','m3','m4','m5','d0','d1','d2'];
 c('Искра: в атласе все 23 утверждённых кадра',need.every(n=>SP.ATL.f[n]));
 c('Искра: без браузера не рисует, игра берёт запасной вид',SP.ready()===false&&SP.draw({},{},0,'level',{PH:24})===false);
 c('хитбокс героя не менялся (20×24), прыжок и управление те же',GE.PW===20&&GE.PH===24&&tap>55&&tap<80&&hold>110&&hold<135);
 c('форма Искры 0..3 хранится и ограничена',SP.form(7)===3&&SP.form(-1)===0)}

/* ---- графика 0.7.0: 20 фонов, предметы и интерфейс рисуются без ошибок ---- */
{const GA=ld('art.js','GameArt');const G={addColorStop(){}};const ctx=new Proxy({},{get:(o,k)=>k in o?o[k]:(k==='createLinearGradient'||k==='createRadialGradient')?()=>G:(k==='measureText')?()=>({width:10}):()=>{},set:(o,k,v)=>{o[k]=v;return true}});
 const names=new Set(),pal=new Set();let ok=true;
 for(let L=1;L<=20;L++){const th=GA.theme('level',L);names.add(th.m+th.name);pal.add(th.top+th.bot+th.ac);try{GA.bg(ctx,360,640,435,5000+L*37,L*1.3,th,1)}catch(e){ok=false;console.log(e.message)}}
 c('графика: 20 уровней рисуют фон без ошибок',ok);
 c('графика: 4 сцены на уровни 1–20, смена раз в 5 уровней (не новый фон на каждый уровень)',pal.size===4&&GA.theme('level',5).top===GA.theme('level',1).top&&GA.theme('level',6).top!==GA.theme('level',5).top);
 c('графика: 20 сцен на уровни 1–100, главы по 10 уровней (текстура земли 0–9), бесконечный режим отдельно',(()=>{const sc=new Set();let ok=true;for(let L=1;L<=100;L++){const th=GA.theme('level',L);sc.add(th.top+th.bot);if(th.tex!==Math.floor((L-1)/10))ok=false}return ok&&sc.size===20&&GA.theme('endless',1).i===11})());
c('графика: 8 сцен на уровни 1–40, смена раз в 10 уровней по главам, текстуры земли 0–3 (главы 1–4)',(()=>{const sc=new Set();let ok=true;for(let L=1;L<=40;L++){const th=GA.theme('level',L);sc.add(th.top+th.bot);if(th.tex!==Math.floor(((L-1)%40)/10))ok=false}return ok&&sc.size===8})());
 let ok2=true;const th=GA.theme('level',3);try{for(const t of['byte','gold','bug','door','proj','fix','shield','magnet','zone'])if(!GA.item(ctx,{t,x:10,w:80,age:.5,big:true},100,300,435,1,640))ok2=false;
  GA.seg(ctx,0,300,435,640,100,th,1);GA.voidFill(ctx,360,640,435,th,1);GA.shadow(ctx,80,435,400,24);GA.plat(ctx,0,300,100,10);for(const st of['warn','stale','lit'])GA.plat(ctx,0,300,100,10,st);GA.arenaHud(ctx,{score:5,bytes:3,hearts:2,maxHearts:3},360,640,1,{font:'sans-serif',name:'Босс',frac:.5});GA.joy(ctx,60,500,.5,true);GA.jump(ctx,300,500,true);GA.rejectBtn(ctx,300,400,true,'Отклонить','sans-serif');
  const S=AR.create({W:360,H:520,seed:1,id:1,bytes:0});GA.parts(ctx,S,S.t,th,1,GE);GA.hud(ctx,{score:5,bytes:3,combo:12,hearts:3,maxHearts:5},360,640,1,{th,font:'sans-serif',hearts:true,f:.4,label:'3 · Архивариус'});
  ok2=ok2&&GA.arenaBg(ctx,{bid:1,gy:430},360,520,1)&&GA.arenaBg(ctx,{bid:2,gy:430},360,520,1)&&[3,4,5,6,7,8,9,10].every(id=>GA.arenaBg(ctx,{bid:id,gy:430},360,520,1)===true)}catch(e){ok2=false;console.log(e.message)}
 c('графика: предметы, земля, интерфейс, частицы и арены 1–10 рисуются без ошибок',ok2)}
{const fs=require('fs'),path=require('path'),dir=path.join(__dirname,'../../app/src/main/assets/features/game');
 const sj=fs.readFileSync(path.join(dir,'spark.js'),'utf8'),atl=JSON.parse(sj.match(/const ATL=(\{.*?\});\n/s)[1]);
 const need=['idle','idle_b','front','front_b','front_h','front_a','front_x','front_s',...[0,1,2,3,4,5,6,7].map(i=>'r'+i),...[0,1,2,3,4,5,6,7].map(i=>'r'+i+'_x')];
 c('Искра: в атласе есть все кадры бега, прыжка, урона, моргания и выражений на фронтальном виде',need.every(n=>atl.f[n]));
 const png=fs.readFileSync(path.join(dir,'spark/spark.png')),W=png.readUInt32BE(16),H=png.readUInt32BE(20);
 c('Искра: все кадры лежат внутри картинки атласа',Object.values(atl.f).every(f=>f[0]+f[2]<=W&&f[1]+f[3]<=H));
 c('Искра: рисование без вращения и сжатия кадра (прыжок берёт позы бега)',!/ctx\.rotate\(lean|sy\*=|sx\*=/.test(sj));}
{const fs=require('fs'),path=require('path'),dir=path.join(__dirname,'../../app/src/main/assets/features/game');let bad2=[];
 for(const f of['art.js','bossart.js','game.js','game.css','fx.js','spark.js']){const txt=fs.readFileSync(path.join(dir,f),'utf8');for(const m of txt.matchAll(/#([0-9a-fA-F]{6})\b/g)){const n=parseInt(m[1],16),r=n>>16,g=(n>>8)&255,b=n&255,mx=Math.max(r,g,b),mn=Math.min(r,g,b);if(mx-mn<18)continue;
   let h;if(mx===r)h=((g-b)/(mx-mn)+6)%6*60;else if(mx===g)h=((b-r)/(mx-mn)+2)*60;else h=((r-g)/(mx-mn)+4)*60;
   const ok=(h<12||h>348)||(h>=30&&h<=50)||(h>=100&&h<=160)||(h>=160&&h<=245);if(!ok)bad2.push(f+' #'+m[1]+' hue '+Math.round(h))}}
 c('палитра: в коде игры нет фиолетовых и розовых оттенков; разрешены тёмно-синий, голубой, золотой, зелёный и красный из утверждённого концепта'+(bad2.length?' '+bad2.slice(0,6).join('; '):''),bad2.length===0)}

/* ---- ядро: страж ошибок, хранилище, статистика ---- */
{const C2=ld('core.js','GameCore');
 c('ядро: guard ловит ошибку и пишет в журнал',(()=>{C2.guard(()=>{throw new Error('x')},'t');return C2.errors.length===1&&C2.errors[0].m==='x'})());
 c('ядро: 5 ошибок подряд = fatal, успех сбрасывает',(()=>{C2.resetErrors();for(let i=0;i<4;i++)C2.guard(()=>{throw 1});const a=C2.fatal();C2.guard(()=>1);for(let i=0;i<5;i++)C2.guard(()=>{throw 1});return !a&&C2.fatal()})());
 c('ядро: хранилище работает без localStorage (память)',(()=>{C2.store.write('k','{"a":1}');return C2.store.json('k',null).a===1&&C2.store.read('нет')===null&&C2.store.json('нет',7)===7})());
 c('ядро: статистика кадров считает худший',(()=>{for(let i=0;i<120;i++)C2.frame(i===5?50:16);return C2.stats.worst>=50})());
 c('ядро: фиксированный шаг не больше 6 за кадр',C2.steps(0,1).n===6)}
/* ---- босс 1 (v3: 404, шахта) проверяется в boss12.test.js; здесь — что арена 3 и 4 не сломаны ---- */
{const S=AR.create({W:360,H:520,seed:21,id:3});S.hearts=999;S.p.inv=1e9;S.boss.hp=100;S.boss.phase=1;S.fallT=99;S.atk=99;S.inval=99;S.sbT=99;
  const take=()=>{S.sbytes=[{x:S.p.x,y:S.p.y+12,t:6}];AR.step(S,1/60,{ax:0});S.ev.length=0};
  for(let i=0;i<4;i++)take();
  c('босс 3: четыре свежих байта ещё не пульс (HP 100, счётчик 4)',S.boss.hp===100&&S.sb===4);
  take();
  c('босс 3: пятый байт = пульс 20 % (HP 80), счётчик сброшен',Math.abs(S.boss.hp-80)<.01&&S.sb===0);
 const S2=AR.create({W:360,H:520,seed:21,id:3});S2.hearts=999;S2.p.inv=1e9;S2.boss.hp=100;S2.boss.phase=1;S2.fallT=99;S2.atk=99;
 let warnAt=-1,swapAt=-1,before=null;
 for(let f=0;f<60*12;f++){S2.p.inv=1e9;const pre=S2.nextStale;AR.step(S2,1/60,{ax:0});S2.ev.length=0;
  if(S2.invW&&warnAt<0){warnAt=S2.t;before=S2.pl.map(q=>!!q.stale)}
  if(warnAt>=0&&swapAt<0&&!S2.invW){swapAt=S2.t}
  if(swapAt>=0)break}
 c('босс 3: предупреждение инвалидации за ~1 с до смены зон ('+(swapAt-warnAt).toFixed(2)+' с)',warnAt>0&&swapAt>0&&Math.abs((swapAt-warnAt)-1)<.1);
}

/* ---- Stale (глава 3), по дизайну: пол, привычки ИИ, копия, веер, байты на свежих платформах ---- */
{const S=AR.create({W:360,H:520,seed:5,id:3});S.hearts=999;S.boss.hp=60;let floorStale=false;
 for(let f=0;f<60*70;f++){S.p.inv=1e9;AR.step(S,1/60,{ax:0});S.ev.length=0;if(S.pl[0].stale||S.pl[1].stale)floorStale=true}
 c('Stale: пол всегда свежий',!floorStale);
 const T=AR.create({W:360,H:520,seed:5,id:3});T.hearts=999;T.boss.hp=20;T.atk=1e9;T.fallT=1e9;T.sbT=1e9;let oneFresh=true;
 for(let f=0;f<60*70;f++){T.p.inv=1e9;AR.step(T,1/60,{ax:0});T.ev.length=0;if(T.pl.slice(2).every(q=>q.stale))oneFresh=false}
 c('Stale, фаза 3: среди поднятых платформ всегда есть свежая',oneFresh)}
{const S=AR.create({W:360,H:520,seed:9,id:3});S.hearts=999;S.boss.hp=100;S.atk=1e9;S.fallT=1e9;S.sbT=1e9;const q=S.pl[3];let warnT=-1;
 for(let f=0;f<60*12&&warnT<0;f++){S.p.inv=1e9;S.p.x=q.x+q.w/2;S.p.y=q.y-GE.PH;S.p.on=true;S.p.vy=0;AR.step(S,1/60,{ax:0});S.ev.length=0;if(S.invW)warnT=S.t}
 c('Stale ИИ: устаревает платформа, где игрок стоит дольше всего',warnT>0&&S.nxt.includes(3))}
{const S=AR.create({W:360,H:520,seed:3,id:3});S.hearts=3;S.boss.hp=50;S.atk=1e9;S.fallT=1e9;S.inval=1e9;S.sbT=1e9;let f=0;
 while(S.hearts===3&&f<60*6){AR.step(S,1/60,{ax:0});S.ev.length=0;f++}
 c('Stale, фаза 2: копия бьёт того, кто стоит там, где был 3 с назад ('+f+' шагов)',S.hearts===2&&f>=178&&f<=200)}
{const S=AR.create({W:360,H:520,seed:4,id:3});S.hearts=999;S.p.inv=1e9;S.atk=0;S.fallT=1e9;S.inval=1e9;S.sbT=1e9;AR.step(S,1/60,{ax:0});const tl=S.tel.find(a=>a.k==='fan');
 c('Stale: веер предупреждает 0,5 с и летит 340 px/с ('+(tl?tl.t.toFixed(2):'нет')+' с)',!!tl&&tl.t>.45&&tl.t<=.5&&tl.v===340)}
{const S=AR.create({W:360,H:520,seed:6,id:3});S.hearts=999;S.p.inv=1e9;S.boss.hp=60;S.atk=1e9;S.fallT=1e9;S.sbT=0;let bad=0,born=0;
 for(let f=0;f<60*40;f++){S.p.inv=1e9;const before=new Set(S.sbytes);AR.step(S,1/60,{ax:0});S.ev.length=0;
  for(const b of S.sbytes){if(before.has(b))continue;born++;const q=S.pl.find(q=>q.st!=='gone'&&b.x>q.x&&b.x<q.x+q.w&&Math.abs(b.y+22-q.y)<1);if(!q||q.stale)bad++}}
 c('Stale: свежий байт появляется только на свежей платформе ('+born+' появлений, нарушений '+bad+')',born>5&&bad===0)}
/* ---- босс 4 (Таймаут) по сюжету: рельсы, обрыв 2 с, ACK доставляется к индикатору ---- */
{const S=AR.create({W:360,H:520,seed:3,id:4});S.hearts=99;const x0=S.pl[2].x;let mv=0,carried=true;
 for(let f=0;f<60*20;f++){AR.step(S,1/60,{ax:0});S.atk=99;if(Math.abs(S.pl[2].x-x0)>10)mv=1}
 c('босс 4: платформы едут по рельсам',mv===1);
 const S2=AR.create({W:360,H:520,seed:3,id:4});S2.hearts=99;S2.atk=99;S2.pl[4].st='ok';S2.kt=0;let k=null,dl=0;
 for(let f=0;f<60*30&&!dl;f++){S2.atk=99;AR.step(S2,1/60,{ax:0});k=S2.key;if(k&&!k.dl&&S2.t>1){S2.p.x=k.x;S2.p.y=k.y-GE.PH/2}else if(k&&k.dl)dl=1}
 const hp=S2.boss.hp;c('босс 4: пойманный ACK ещё не бьёт босса, нужно доставить к индикатору',dl===1&&S2.boss.hp===hp);
 for(let f=0;f<5&&S2.key;f++){S2.p.x=S2.key.x;S2.p.y=S2.key.y-GE.PH/2;S2.p.vy=0;AR.step(S2,1/60,{ax:0})}
 c('босс 4: доставка ACK бьёт босса',S2.boss.hp<hp);
 const S3=AR.create({W:360,H:520,seed:3,id:4});S3.key={x:50,y:50,t:1e9,dl:1,q:4};S3.p.inv=0;S3.sh.push({x:S3.p.x,y:S3.p.y+12,vx:0,vy:0,r:8,kind:2});AR.step(S3,1/60,{ax:0});
 c('босс 4: удар роняет несомый ACK',S3.key===null)}

/* ---- 0.17.3: плавный прыжок и адаптивное качество ---- */
{/* гравитация при удержании: нет ступеньки, высоты и время в воздухе как раньше */
 const G=GE.G,JV=GE.JV,HM=GE.HMAX,DT=1/1200;
 const jump=hold=>{let y=0,vy=-JV,t=0,h=HM,top=0,prev=null,maxd=0;
  while(true){const down=hold==null||t<hold;let g=G;
   if(down&&vy<0&&h>0){g=G*GE.gMul(h);h-=DT}else if(!down)h=0;
   if(prev!=null&&hold==null)maxd=Math.max(maxd,Math.abs(g-prev));prev=g;
   vy+=g*DT;y+=vy*DT;t+=DT;top=Math.max(top,-y);if(y>=0)break}
  return{top,t,maxd}};
 const tap=jump(0),h1=jump(.1),full=jump(null);
 c('прыжок: тап 65,6 px ('+tap.top.toFixed(1)+')',Math.abs(tap.top-65.6)<.8);
 c('прыжок: удержание 0,1 с 92,3 px ('+h1.top.toFixed(1)+')',Math.abs(h1.top-92.3)<1);
 c('прыжок: полное удержание 123,2 px, не выше прежних 123,8 ('+full.top.toFixed(1)+')',full.top<=123.8&&full.top>=122.4);
 c('прыжок: в воздухе 0,77 с ('+full.t.toFixed(3)+')',Math.abs(full.t-.77)<.015);
 c('прыжок: гравитация без скачка (макс. шаг '+(full.maxd*DT*60/ (1/1200*60)).toFixed(0)+' px/с² за шаг 1/1200 с, раньше 1102)',full.maxd<30);
 c('прыжок: gMul от HG до 1 без разрывов',Math.abs(GE.gMul(HM)-GE.HG)<1e-9&&Math.abs(GE.gMul(0)-1)<1e-9)}
{/* ядро: адаптивное качество */
 const mk=()=>ld('core.js','GameCore');
 let K=mk();for(let i=0;i<40;i++)K.tick(22);c('ядро: стабильные 45 кадров/с (22 мс) снижают качество за 40 кадров',K.perf.q<1);
 K=mk();let ch=0;for(let i=0;i<300;i++)if(K.tick(i%20===0?120:16.7))ch++;c('ядро: одиночные провалы кадра (120 мс раз в 20 кадров) качество не снижают',K.perf.q===1&&ch===0);
 K=mk();K.settle();let ch2=0;for(let i=0;i<55;i++)if(K.tick(40))ch2++;c('ядро: после settle() 55 кадров не оцениваются',ch2===0&&K.perf.q===1);
 K=mk();K.tick(500);K.tick(1200);c('ядро: кадр дольше 400 мс (пауза вкладки) не считается',K.perf.since===0);
 K=mk();const dp=[];dp.push(K.dprFor(2));for(let s=0;s<3;s++){for(let i=0;i<200&&!K.tick(40););dp.push(K.dprFor(2))}
 c('ядро: ступени холста 2 → 1,5 → 1,25 → 1 ('+dp.join(' → ')+')',dp.join()==='2,1.5,1.25,1');
 c('ядро: на экране 1× холст не меньше 1 ('+K.dprFor(1)+')',K.dprFor(1)===1);
 K=mk();for(let i=0;i<60;i++)K.tick(40);const lv=K.perf.lv;for(let i=0;i<700;i++)K.tick(12);c('ядро: после 10 с быстрой игры качество поднимается на ступень ('+lv+' → '+K.perf.lv+')',lv>0&&K.perf.lv===lv-1);
 K=mk();for(let i=0;i<60;i++)K.tick(40);for(let i=0;i<700;i++)K.tick(12);const up=K.perf.lv;for(let i=0;i<200&&K.perf.lv===up;i++)K.tick(40);
 for(let i=0;i<3000;i++)K.tick(12);c('ядро: если сразу после подъёма снова тормозит, выше этой ступени не поднимается (cap '+K.perf.cap+', ступень '+K.perf.lv+')',K.perf.cap>0&&K.perf.lv>=K.perf.cap)}
console.log('\nИТОГ: %d ок, %d провалов',ok,bad.length);if(bad.length){console.log(bad);process.exit(1)}
